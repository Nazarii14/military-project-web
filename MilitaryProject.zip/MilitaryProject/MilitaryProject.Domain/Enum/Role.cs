﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MilitaryProject.Domain.Enum
{
    public enum Role
    {
        Admin,
        Commander,
        Soldier,
        Volunteer,
        Guest
    }
}
